<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name:"App"
}
</script>


<!-- deklarasi root style-->
<!-- <style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px; /* Add some margin to separate the navbar from the content */
}
</style> -->
